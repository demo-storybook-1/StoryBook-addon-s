import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-angular-dsm',
  template: `
    <p>
      angular-dsm works!!!
    </p>
  `,
  styles: [
  ]
})
export class AngularDsmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
