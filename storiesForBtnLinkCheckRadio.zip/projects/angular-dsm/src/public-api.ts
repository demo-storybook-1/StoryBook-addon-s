/*
 * Public API Surface of angular-dsm
 */

export * from './lib/index';
